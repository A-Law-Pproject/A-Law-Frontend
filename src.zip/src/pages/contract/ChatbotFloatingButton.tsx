import React, { useRef, useState } from "react";

interface Props {
  onClick: () => void;
}

function ChatbotFloatingButton({ onClick }: Props) {
  const [pos, setPos] = useState({ x: window.innerWidth - 80, y: window.innerHeight - 160 });
  const dragging = useRef(false);
  const offset = useRef({ x: 0, y: 0 });

  const onMouseDown = (e: React.MouseEvent) => {
    dragging.current = true;
    offset.current = {
      x: e.clientX - pos.x,
      y: e.clientY - pos.y,
    };
  };

  const onMouseMove = (e: MouseEvent) => {
    if (!dragging.current) return;
    setPos({
      x: e.clientX - offset.current.x,
      y: e.clientY - offset.current.y,
    });
  };

  const onMouseUp = () => {
    dragging.current = false;
  };

  React.useEffect(() => {
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
    };
  });

  return (
    <div
      onMouseDown={onMouseDown}
      onClick={onClick}
      style={{
        position: "fixed",
        left: pos.x,
        top: pos.y,
        width: 56,
        height: 56,
        borderRadius: "50%",
        background: "linear-gradient(135deg, #21D8FC, #5865B9)",
        boxShadow: "0 6px 16px rgba(0,0,0,0.25)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        color: "white",
        fontSize: 26,
        cursor: "pointer",
        zIndex: 30,
        userSelect: "none",
      }}
    >
      🤖
    </div>
  );
}

export default ChatbotFloatingButton;
